# ARAZVERA — Agent governance Buyer Evidence Pack

This is an **illustrative, source-free** example, not the private module or a buyer-accepted finished integration.

## Matching private technical starter IDs (metadata only)

- ARAZVERA-L2-AI-EVALUATION-001 — AI Evaluation; 8 archived local tests; technically verified
- ARAZVERA-L2-OIDC-JWKS-BOUNDARY-001 — OIDC JWKS Boundary; 49 archived local tests; technically verified
- ARAZVERA-L2-PROVIDER-NEUTRAL-AI-001 — Provider Neutral AI; 10 archived local tests; technically verified
- ARAZVERA-L2-SECURE-AI-INTAKE-ASSISTANT-001 — Secure AI Intake Assistant; 2 archived local tests; technically verified
- ARAZVERA-L1-TEXT-ASSISTANT-KIT — Text assistant starter; private kit; individual test count not independently rerun
- ARAZVERA-L5-001 — Agent Governance Foundation; part of L5 suite (158 locally rerun tests overall); per-product count not asserted
- ARAZVERA-L5-002 — MCP Manifest Trust; part of L5 suite (158 locally rerun tests overall); per-product count not asserted
- ARAZVERA-L5-003 — Agent FinOps v0.1.1; part of L5 suite (158 locally rerun tests overall); per-product count not asserted
- ARAZVERA-L5-007 — Premium Agent Control v0.1.1; part of L5 suite (158 locally rerun tests overall); per-product count not asserted
- ARAZVERA-L5-008 — Agent Delegation; part of L5 suite (158 locally rerun tests overall); per-product count not asserted
- ARAZVERA-L5-010 — MCP Schema; part of L5 suite (158 locally rerun tests overall); per-product count not asserted
- ARAZVERA-L5-013 — MCP HTTP Boundary v0.1.1; part of L5 suite (158 locally rerun tests overall); per-product count not asserted
- L7-AGENT-SECURITY-CONTROL-001 — Agent Security Control; part of L7 workspace (82 reported local tests); per-product count not asserted

## Demo files
- safe synthetic sample: `agent_pass.json`
- failure injection: `agent_issues.json`

## Contracted changes still required
Customer requirements, approved accounts and endpoints, software IP and permissions, integration, security, regression tests, staging acceptance and any deployment are subject to a written agreement.

PUBLIC SYNTHETIC EVIDENCE / NOT A PRODUCTION SERVICE
All results in this package are computed by ARAZVERA's source-free browser demonstration, not by proprietary L1-L7 code.
Do not interpret test output as regulatory certification, payment eligibility, source license, or customer acceptance.
Technical work and payment with an Iran-resident developer require independent legal/contracting review.
Start with a written problem statement and sanitized examples. Never send credentials or private customer data.

Proof lab: https://arazvera-technologies.github.io/buyer-lab/
Public GitHub: https://github.com/arazvera-technologies/arazvera-engineering-portfolio
Written contact: contact.arazvera@gmail.com
